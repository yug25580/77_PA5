/*
 * partA.c  --  CSE231 PA-5, Part A: a user-space demand pager.
 *
 * The square-root table (2^27 doubles = 1 GiB of virtual addresses) can never
 * be mapped under RLIMIT_AS = 8 MiB.  Its address range is merely *reserved*
 * (nothing is mapped there), so the first touch of any entry makes the MMU
 * raise a page fault, which Linux turns into SIGSEGV.  handle_sigsegv() below
 * is therefore a tiny pager:  it receives the "page fault", evicts the one
 * page it kept resident, maps a fresh page at the faulting address, fills it
 * with the right square roots and returns, so the CPU re-executes the
 * faulting instruction and now succeeds.
 *
 * Course topics used (tags refer to the lecture / tutorial numbers):
 *   [L10, T9]   signals: sigaction + SA_SIGINFO, siginfo_t, async-signal-safety
 *   [L18-L20]   virtual memory, VPN/offset split, page = unit of mapping,
 *               page fault -> OS maps a frame -> instruction is retried
 *   [L20/L22]   demand paging: a page is brought in only when first touched
 *   [T10]       mmap / munmap, MAP_FIXED, MAP_PRIVATE|MAP_ANONYMOUS,
 *               MAP_FAILED check, zero-fill-on-demand anonymous memory
 *   [L7]        a fault is a synchronous trap/exception; the kernel delivers
 *               it to the process as a signal (SIGSEGV)
 *
 * Everything outside handle_sigsegv() (and the small helpers just above it)
 * is the unmodified starter code.
 *
 * Build:  gcc -O2 -Wall -Wextra -o partA partA.c -lm
 */
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <math.h>

static size_t page_size;

// align_down - rounds a value down to an alignment
// @x: the value
// @a: the alignment (must be power of 2)
//
// Returns an aligned value.
#define align_down(x, a) ((x) & ~((typeof(x))(a) - 1))

#define AS_LIMIT	(1 << 23) // Maximum limit on virtual memory bytes
#define MAX_SQRTS	(1 << 27) // Maximum limit on sqrt table entries
static double *sqrts;

// Use this helper function as an oracle for square root values.
static void
calculate_sqrts(double *sqrt_pos, int start, int nr)
{
  int i;

  for (i = 0; i < nr; i++)
    sqrt_pos[i] = sqrt((double)(start + i));
}

/* ------------------------------------------------------------------------
 * Pager state.
 *
 * resident_page is the base address of the ONE page that is currently mapped
 * (0 means "nothing mapped yet").  It is only touched from inside the signal
 * handler, and SIGSEGV is blocked while the handler runs (sa_mask / default
 * behaviour), so no locking is needed.
 * ---------------------------------------------------------------------- */
static uintptr_t resident_page;

/* ------------------------------------------------------------------------
 * Async-signal-safe error reporting.
 *
 * printf() is NOT safe in a signal handler: stdio keeps a shared buffer plus
 * index/lock state, and the signal may have interrupted printf itself (or
 * malloc, which printf may call), leaving that state half updated -> garbled
 * output, deadlock or heap corruption.  write(2) and _exit(2) are on the
 * POSIX async-signal-safe list (signal-safety(7)), so we use only those.
 * ---------------------------------------------------------------------- */
static void
sig_puts(const char *s)
{
  /* strlen() is a pure function with no global state; written out by hand
   * here so that nothing but write() touches shared resources. */
  size_t n = 0;
  while (s[n] != '\0')
    n++;
  /* The return value is deliberately ignored: we are about to die anyway and
   * there is nobody left to report a failed diagnostic to. */
  ssize_t r = write(STDERR_FILENO, s, n);
  (void)r;
}

static void
sig_put_hex(uintptr_t v)
{
  char buf[2 + 2 * sizeof(uintptr_t) + 1];
  int i = (int)sizeof(buf) - 1;

  buf[i] = '\0';
  do {
    buf[--i] = "0123456789abcdef"[v & 0xf];
    v >>= 4;
  } while (v != 0);
  buf[--i] = 'x';
  buf[--i] = '0';
  sig_puts(&buf[i]);
}

/* Print "<msg> at 0x<addr>\n" and terminate with EXIT_FAILURE. */
static void
sig_die(const char *msg, uintptr_t addr)
{
  sig_puts(msg);
  sig_puts(" at ");
  sig_put_hex(addr);
  sig_puts("\n");
  _exit(EXIT_FAILURE);   /* _exit, not exit(): exit() runs atexit/stdio code */
}

/* ------------------------------------------------------------------------
 * handle_sigsegv - the "page-fault handler".
 * ---------------------------------------------------------------------- */
static void
handle_sigsegv(int sig, siginfo_t *si, void *ctx)
{
  (void)sig;
  (void)ctx;

  /* mmap/munmap may overwrite errno; the interrupted code could be in the
   * middle of using errno, so save it and put it back before returning
   * (signal-safety(7) requires this for handlers that touch errno). */
  int saved_errno = errno;

  /* Step 1: the faulting address as reported by the kernel. */
  uintptr_t fault_addr = (uintptr_t)si->si_addr;

  /* Step 2: is it inside the table [sqrts, sqrts + MAX_SQRTS*8) ?
   * If not, this is a genuine bug (NULL dereference, stack overflow, ...):
   * "fixing" it by mapping memory would hide the bug or clobber a valid
   * mapping, so report it and exit.
   * We also insist on si_code == SEGV_MAPERR ("address not mapped").  A
   * SEGV_ACCERR fault would mean a *mapped* page was accessed illegally;
   * remapping that page could never cure it and the instruction would fault
   * forever, so it is treated as a bug too. */
  uintptr_t table_lo = (uintptr_t)sqrts;
  uintptr_t table_hi = table_lo + (uintptr_t)MAX_SQRTS * sizeof(double);

  if (fault_addr < table_lo || fault_addr >= table_hi ||
      si->si_code != SEGV_MAPERR)
    sig_die("genuine SIGSEGV (outside the sqrt table / not a missing page)",
            fault_addr);

  /* Step 3: round down to the page boundary: this is "VPN << PAGE_SHIFT",
   * i.e. drop the offset bits  [L20 VPN/offset]. */
  uintptr_t page = align_down(fault_addr, page_size);

  /* Step 4: evict the previously resident page so that the process's total
   * mapped size stays far below RLIMIT_AS.  munmap() both removes the
   * virtual mapping AND frees the physical frame, so nothing leaks.
   * On the very first fault nothing is resident yet. */
  if (resident_page != 0) {
    if (munmap((void *)resident_page, page_size) == -1)
      sig_die("munmap of the evicted page failed", resident_page);
    resident_page = 0;
  }

  /* Step 5: map a fresh anonymous read/write page exactly at 'page'.
   * MAP_FIXED forces that address (the range is free, we unmapped / never
   * mapped it); MAP_PRIVATE|MAP_ANONYMOUS gives zero-filled memory that is
   * physically allocated on first write  [T10].
   * Without MAP_FIXED the kernel would treat 'page' only as a hint and could
   * return a different address, leaving the faulting address still unmapped
   * (-> infinite fault loop). So we verify we really got what we asked for. */
  void *p = mmap((void *)page, page_size, PROT_READ | PROT_WRITE,
                 MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (p == MAP_FAILED || (uintptr_t)p != page)
    sig_die("mmap of the new page failed", page);
  resident_page = page;

  /* Step 6: fill the page with the right values.
   * The table element index of the first double on this page is
   *     (page - table_base) / sizeof(double)
   * (table_base is page aligned, so this is always an exact multiple of
   * page_size/8 = 512 entries).  Getting this start index wrong is the
   * classic off-by-one bug: every value would be shifted and the test would
   * print "Square root is incorrect". */
  int start = (int)((page - table_lo) / sizeof(double));
  int nr    = (int)(page_size / sizeof(double));
  calculate_sqrts((double *)page, start, nr);

  /* Step 7: return.  The kernel restores the interrupted context
   * (sigreturn) and the CPU re-executes the faulting load, which now hits
   * the freshly mapped page.  [L10 "Catching the signal"] */
  errno = saved_errno;
}

static void
setup_sqrt_region(void)
{
  struct rlimit lim = {AS_LIMIT, AS_LIMIT};
  struct sigaction act;

  // Only mapping to find a safe location for the table.
  sqrts = mmap(NULL, MAX_SQRTS * sizeof(double) + AS_LIMIT, PROT_NONE,
	       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sqrts == MAP_FAILED) {
    fprintf(stderr, "Couldn't mmap() region for sqrt table; %s\n",
	    strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Now release the virtual memory to remain under the rlimit.
  if (munmap(sqrts, MAX_SQRTS * sizeof(double) + AS_LIMIT) == -1) {
    fprintf(stderr, "Couldn't munmap() region for sqrt table; %s\n",
            strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Set a soft rlimit on virtual address-space bytes.
  if (setrlimit(RLIMIT_AS, &lim) == -1) {
    fprintf(stderr, "Couldn't set rlimit on RLIMIT_AS; %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Register a signal handler to capture SIGSEGV.
  act.sa_sigaction = handle_sigsegv;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

static void
test_sqrt_region(void)
{
  int i, pos = rand() % (MAX_SQRTS - 1);
  double correct_sqrt;

  printf("Validating square root table contents...\n");
  srand(0xDEADBEEF);

  for (i = 0; i < 500000; i++) {
    if (i % 2 == 0)
      pos = rand() % (MAX_SQRTS - 1);
    else
      pos += 1;
    calculate_sqrts(&correct_sqrt, pos, 1);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }

  printf("All tests passed!\n");
}

int
main(int argc, char *argv[])
{
  (void)argc;
  (void)argv;
  page_size = sysconf(_SC_PAGESIZE);
  printf("page_size is %ld\n", page_size);
  setup_sqrt_region();
  test_sqrt_region();
  return 0;
}
