/*
 * partC.c  --  CSE231 PA-5, Part C: using madvise() in the pager.
 *
 * This is the Part B pager (CHUNK_PAGES / RESIDENT_CHUNKS, FIFO eviction)
 * with three independent, compile-time selectable experiments:
 *
 *   C1  -DC1_DONTNEED      madvise(victim, len, MADV_DONTNEED) just BEFORE
 *                          the evicted chunk is munmap()ed.
 *   C2  -DC2_SEQUENTIAL    madvise(chunk, len, MADV_SEQUENTIAL) right after
 *       -DC2_RANDOM        (or MADV_RANDOM) a chunk has been mapped.
 *   C3  -DC3_PREFETCH      also map + fill the NEXT chunk in the handler
 *                          (simple read-ahead).  Needs RESIDENT_CHUNKS >= 2.
 *       -DC3_WILLNEED      prefetch AND madvise(next, len, MADV_WILLNEED).
 *
 * Flags can be combined, but each experiment is meant to be measured alone
 * against the same base configuration (see Makefile / scripts).
 *
 * Extra (not required by the handout): -DSEQ_TEST replaces the starter's
 * validation (random jumps + "pos+1") by a purely SEQUENTIAL walk over the
 * first 2^22 table entries.  It is used in the report to show when C3's
 * read-ahead actually pays off (the starter's "sequential half" only touches
 * ONE neighbour of each random position, so it rarely crosses a chunk).
 *
 * Course topics used (tags refer to the lecture / tutorial numbers):
 *   [T10]       madvise(): usage hints for an EXISTING mapping, most advice
 *               values are hints (not guarantees); MADV_DONTNEED semantics
 *               for private anonymous memory (next touch = zero-filled page);
 *               MADV_SEQUENTIAL / RANDOM / WILLNEED are about read-ahead
 *               (file page cache); mmap vs madvise vs munmap are three
 *               different things
 *   [L20-L22]   demand paging, zero-fill-on-demand, working set, locality
 *               (prefetch pays only if spatial locality exists), cost model
 *               EAT = hit time + miss rate * miss penalty
 *   [L22]       page replacement: FIFO eviction of the resident set
 *   [L10, T9]   async-signal-safe handler (write/_exit only), sigaction
 *   [L18]       RLIMIT_AS limits *virtual* size: mappings count even when
 *               they hold no physical memory (central to C1's design Q)
 *
 * Build, e.g.:
 *   gcc -O2 -Wall -Wextra -DCHUNK_PAGES=4 -DRESIDENT_CHUNKS=4 \
 *       -DC3_PREFETCH -o partC3 partC.c -lm
 */
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <math.h>

#ifndef CHUNK_PAGES
#define CHUNK_PAGES 1
#endif
#ifndef RESIDENT_CHUNKS
#define RESIDENT_CHUNKS 1
#endif
#if CHUNK_PAGES < 1 || RESIDENT_CHUNKS < 1
#error "CHUNK_PAGES and RESIDENT_CHUNKS must both be >= 1"
#endif

/* ---- experiment selection ---------------------------------------------- */
#ifdef C3_WILLNEED
#ifndef C3_PREFETCH
#define C3_PREFETCH             /* WILLNEED is meaningless without prefetch */
#endif
#endif

#if defined(C3_PREFETCH) && RESIDENT_CHUNKS < 2
/* With a single resident chunk the prefetch of chunk N+1 would evict chunk N
 * (the very chunk we are faulting on) -> the retried instruction faults again
 * -> infinite fault loop.  We refuse to build such a configuration. */
#error "C3 prefetch needs RESIDENT_CHUNKS >= 2"
#endif

#if defined(C2_SEQUENTIAL) && defined(C2_RANDOM)
#error "choose only one of C2_SEQUENTIAL / C2_RANDOM"
#endif

#if defined(C2_SEQUENTIAL)
#define C2_ADVICE MADV_SEQUENTIAL
#define C2_NAME   "MADV_SEQUENTIAL"
#elif defined(C2_RANDOM)
#define C2_ADVICE MADV_RANDOM
#define C2_NAME   "MADV_RANDOM"
#endif

static size_t page_size;

// align_down - rounds a value down to an alignment
// @x: the value
// @a: the alignment (must be power of 2)
//
// Returns an aligned value.
#define align_down(x, a) ((x) & ~((typeof(x))(a) - 1))

#define AS_LIMIT	(1 << 23) // Maximum limit on virtual memory bytes
#define MAX_SQRTS	(1 << 27) // Maximum limit on sqrt table entries
static double *sqrts;

// Use this helper function as an oracle for square root values.
static void
calculate_sqrts(double *sqrt_pos, int start, int nr)
{
  int i;

  for (i = 0; i < nr; i++)
    sqrt_pos[i] = sqrt((double)(start + i));
}

/* ---- pager state (same FIFO design as partB.c) -------------------------- */
static size_t    chunk_bytes;
static uintptr_t fifo[RESIDENT_CHUNKS];   /* resident chunk base addresses  */
static unsigned  fifo_next;               /* index of the oldest chunk      */
static uintptr_t table_lo, table_hi;      /* [lo, hi) of the sqrt table     */

static volatile unsigned long nr_faults;            /* SIGSEGV invocations   */
static volatile unsigned long nr_faults_phase[2];   /* [0]=random, [1]=pos+1 */
static volatile unsigned long nr_chunks_filled;     /* chunks mapped+filled
                                                       (demand + prefetch)   */
static volatile unsigned long nr_prefetched;        /* of which prefetched   */
static volatile sig_atomic_t  cur_phase;

/* ---- async-signal-safe diagnostics ------------------------------------- */
static void
sig_puts(const char *s)
{
  size_t n = 0;
  while (s[n] != '\0')
    n++;
  ssize_t r = write(STDERR_FILENO, s, n);
  (void)r;
}

static void
sig_put_num(uintptr_t v, unsigned base)
{
  char buf[2 + 2 * sizeof(uintptr_t) + 1];
  int i = (int)sizeof(buf) - 1;

  buf[i] = '\0';
  do {
    buf[--i] = "0123456789abcdef"[v % base];
    v /= base;
  } while (v != 0);
  if (base == 16) {
    buf[--i] = 'x';
    buf[--i] = '0';
  }
  sig_puts(&buf[i]);
}

static void
sig_die(const char *msg, uintptr_t addr, int err)
{
  sig_puts(msg);
  sig_puts(" (addr ");
  sig_put_num(addr, 16);
  sig_puts(", errno ");
  sig_put_num((uintptr_t)err, 10);
  sig_puts(")\n");
  _exit(EXIT_FAILURE);
}

#ifdef C3_PREFETCH
/* is 'chunk' currently in the FIFO?  (tiny linear scan; RESIDENT_CHUNKS is
 * small)  Used by the prefetcher so it never maps over a resident chunk. */
static int
is_resident(uintptr_t chunk)
{
  for (unsigned i = 0; i < RESIDENT_CHUNKS; i++)
    if (fifo[i] == chunk)
      return 1;
  return 0;
}
#endif

/* ------------------------------------------------------------------------
 * install_chunk - make 'chunk' resident:
 *   evict oldest (FIFO) -> mmap(MAP_FIXED) -> [C2 advice] -> FIFO insert ->
 *   fill with square roots.
 * Shared by the demand path and the C3 prefetch path.
 * ---------------------------------------------------------------------- */
static void
install_chunk(uintptr_t chunk)
{
  size_t len = chunk_bytes;
  if (chunk + len > table_hi)               /* clamp the last chunk */
    len = (size_t)(table_hi - chunk);

  /* ---- evict the oldest resident chunk ---------------------------------- */
  uintptr_t victim = fifo[fifo_next];
  if (victim != 0) {
#ifdef C1_DONTNEED
    /* [C1] Tell the kernel the CONTENTS of the victim are no longer needed.
     * For a private anonymous mapping this frees the physical pages
     * immediately (RSS drops) but keeps the virtual mapping; the very next
     * munmap() would have freed the pages anyway, so this is a redundant
     * extra system call here (see report). */
    if (madvise((void *)victim, chunk_bytes, MADV_DONTNEED) == -1)
      sig_die("madvise(MADV_DONTNEED) failed", victim, errno);
#endif
    if (munmap((void *)victim, chunk_bytes) == -1)
      sig_die("munmap of evicted chunk failed", victim, errno);
    fifo[fifo_next] = 0;
  }

  /* ---- map the new chunk exactly at 'chunk' ------------------------------ */
  void *p = mmap((void *)chunk, len, PROT_READ | PROT_WRITE,
                 MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (p == MAP_FAILED || (uintptr_t)p != chunk)
    sig_die("mmap of new chunk failed", chunk, errno);

#ifdef C2_ADVICE
  /* [C2] access-pattern hint for the new mapping.  On anonymous memory
   * there is no backing file to read ahead from, so the kernel accepts the
   * advice (flags the VMA VM_SEQ_READ / VM_RAND_READ) but nothing consumes
   * it on the fault path -> no measurable effect expected. */
  if (madvise((void *)chunk, len, C2_ADVICE) == -1)
    sig_die("madvise(access pattern) failed", chunk, errno);
#endif

  /* ---- FIFO bookkeeping --------------------------------------------------- */
  fifo[fifo_next] = chunk;
  fifo_next = (fifo_next + 1) % RESIDENT_CHUNKS;

  /* ---- fill with the correct square roots --------------------------------- */
  calculate_sqrts((double *)chunk, (int)((chunk - table_lo) / sizeof(double)),
                  (int)(len / sizeof(double)));
  nr_chunks_filled++;
}

static void
handle_sigsegv(int sig, siginfo_t *si, void *ctx)
{
  (void)sig;
  (void)ctx;
  int saved_errno = errno;

  uintptr_t fault_addr = (uintptr_t)si->si_addr;
  if (fault_addr < table_lo || fault_addr >= table_hi ||
      si->si_code != SEGV_MAPERR)
    sig_die("genuine SIGSEGV (outside table / not a missing page)",
            fault_addr, 0);

  nr_faults++;
  nr_faults_phase[cur_phase & 1]++;

  uintptr_t offset = fault_addr - table_lo;
  uintptr_t chunk  = table_lo + (offset - offset % chunk_bytes);

  install_chunk(chunk);                       /* demand-fetch the chunk */

#ifdef C3_PREFETCH
  /* [C3] read-ahead: also bring in the chunk that follows.  If the program
   * is walking the table sequentially, its next fault will be on exactly that
   * chunk, and the SIGSEGV is saved.  If it jumps elsewhere (random half) the
   * work was wasted.  Skip if already resident or past the table's end.
   * Because the FIFO has >= 2 slots, installing 'next' evicts the second
   * oldest chunk, never the one we just installed. */
  uintptr_t next = chunk + chunk_bytes;
  if (next < table_hi && !is_resident(next)) {
    install_chunk(next);
    nr_prefetched++;
#ifdef C3_WILLNEED
    /* [C3] optional hint: "I will use this range soon".  For anonymous
     * memory that is already mapped and filled this is a no-op (the pages
     * are already populated); on file mappings it triggers read-ahead. */
    size_t nlen = chunk_bytes;
    if (next + nlen > table_hi)
      nlen = (size_t)(table_hi - next);
    if (madvise((void *)next, nlen, MADV_WILLNEED) == -1)
      sig_die("madvise(MADV_WILLNEED) failed", next, errno);
#endif
  }
#endif

  errno = saved_errno;
}

static void
setup_sqrt_region(void)
{
  struct rlimit lim = {AS_LIMIT, AS_LIMIT};
  struct sigaction act;

  // Only mapping to find a safe location for the table.
  sqrts = mmap(NULL, MAX_SQRTS * sizeof(double) + AS_LIMIT, PROT_NONE,
	       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sqrts == MAP_FAILED) {
    fprintf(stderr, "Couldn't mmap() region for sqrt table; %s\n",
	    strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Now release the virtual memory to remain under the rlimit.
  if (munmap(sqrts, MAX_SQRTS * sizeof(double) + AS_LIMIT) == -1) {
    fprintf(stderr, "Couldn't munmap() region for sqrt table; %s\n",
            strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Set a soft rlimit on virtual address-space bytes.
  if (setrlimit(RLIMIT_AS, &lim) == -1) {
    fprintf(stderr, "Couldn't set rlimit on RLIMIT_AS; %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  /* cache the table bounds in globals for the handler */
  table_lo = (uintptr_t)sqrts;
  table_hi = table_lo + (uintptr_t)MAX_SQRTS * sizeof(double);

  // Register a signal handler to capture SIGSEGV.
  act.sa_sigaction = handle_sigsegv;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

#ifndef SEQ_TEST   /* starter validation; replaced by test_sequential() under -DSEQ_TEST */
static void
test_sqrt_region(void)
{
  int i, pos = rand() % (MAX_SQRTS - 1);
  double correct_sqrt;

  printf("Validating square root table contents...\n");
  srand(0xDEADBEEF);

  for (i = 0; i < 500000; i++) {
    cur_phase = i & 1;            /* bookkeeping only (see partB.c) */
    if (i % 2 == 0)
      pos = rand() % (MAX_SQRTS - 1);
    else
      pos += 1;
    calculate_sqrts(&correct_sqrt, pos, 1);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }

  printf("All tests passed!\n");
}
#endif /* !SEQ_TEST */

#ifdef SEQ_TEST
/* Purely sequential walk over the first SEQ_ENTRIES table entries (32 MiB of
 * table, 8192 pages).  Every chunk is touched front to back exactly once, so
 * a pager that reads ahead should save SIGSEGVs.  [L22 spatial locality] */
#define SEQ_ENTRIES (1 << 22)
static void
test_sequential(void)
{
  printf("Validating square root table contents (sequential walk)...\n");
  cur_phase = 1;                       /* everything counts as "sequential" */
  for (int pos = 0; pos < SEQ_ENTRIES; pos++) {
    double correct_sqrt = sqrt((double)pos);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }
  printf("All tests passed!\n");
}
#endif

/* [PA5] Peak resident set size of THIS process in KiB, read from
 * /proc/self/status (VmHWM = "high water mark" of the current address space).
 * Why not only ru_maxrss?  Linux keeps ru_maxrss across fork()+exec(): a
 * child started from a large parent (e.g. our benchmark driver, ~15 MB)
 * reports the PARENT's peak, hiding the pager's tiny footprint.  VmHWM is
 * reset by exec, so it measures just this program.  Returns -1 on error.
 * (Only called from main(), never from the signal handler.) */
static long
read_vmhwm_kib(void)
{
  FILE *f = fopen("/proc/self/status", "r");
  char line[256];
  long kib = -1;

  if (f == NULL)
    return -1;
  while (fgets(line, sizeof(line), f) != NULL)
    if (sscanf(line, "VmHWM: %ld kB", &kib) == 1)
      break;
  fclose(f);
  return kib;
}

int
main(int argc, char *argv[])
{
  (void)argc;
  (void)argv;
  page_size = sysconf(_SC_PAGESIZE);
  chunk_bytes = (size_t)CHUNK_PAGES * page_size;
  printf("page_size is %ld\n", page_size);

  /* describe the variant that was compiled */
  const char *variant = "baseline";
#if defined(C3_WILLNEED)
  variant = "C3 prefetch next chunk + MADV_WILLNEED";
#elif defined(C3_PREFETCH)
  variant = "C3 prefetch next chunk";
#elif defined(C2_ADVICE)
  variant = "C2 " C2_NAME;
#elif defined(C1_DONTNEED)
  variant = "C1 MADV_DONTNEED before munmap";
#endif
  printf("config: CHUNK_PAGES=%d RESIDENT_CHUNKS=%d variant=%s\n",
         CHUNK_PAGES, RESIDENT_CHUNKS, variant);

  setup_sqrt_region();

  struct timespec t0, t1;
  clock_gettime(CLOCK_MONOTONIC, &t0);
#ifdef SEQ_TEST
  test_sequential();
#else
  test_sqrt_region();
#endif
  clock_gettime(CLOCK_MONOTONIC, &t1);
  double wall = (double)(t1.tv_sec - t0.tv_sec) +
                (double)(t1.tv_nsec - t0.tv_nsec) / 1e9;

  struct rusage ru;
  if (getrusage(RUSAGE_SELF, &ru) == -1) {
    perror("getrusage");
    return EXIT_FAILURE;
  }
  printf("minor faults: %ld, major faults: %ld, maxrss: %ld KiB\n",
         ru.ru_minflt, ru.ru_majflt, ru.ru_maxrss);
  printf("SIGSEGV handler invocations: %lu (random half %lu, sequential half %lu)\n",
         nr_faults, nr_faults_phase[0], nr_faults_phase[1]);
  printf("chunks filled: %lu (prefetched %lu)\n", nr_chunks_filled, nr_prefetched);
  long hwm = read_vmhwm_kib();
  printf("peak RSS (VmHWM): %ld KiB\n", hwm);
  printf("wall time: %.3f s\n", wall);
  printf("STATS chunk_pages=%d resident_chunks=%d sigsegv=%lu sigsegv_rand=%lu "
         "sigsegv_seq=%lu chunks_filled=%lu prefetched=%lu minflt=%ld "
         "majflt=%ld maxrss_kib=%ld vmhwm_kib=%ld wall_s=%.4f\n",
         CHUNK_PAGES, RESIDENT_CHUNKS, nr_faults, nr_faults_phase[0],
         nr_faults_phase[1], nr_chunks_filled, nr_prefetched, ru.ru_minflt,
         ru.ru_majflt, ru.ru_maxrss, hwm, wall);
  return 0;
}
