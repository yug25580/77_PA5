/*
 * partB.c  --  CSE231 PA-5, Part B: vary the pager's granularity.
 *
 * Same user-space demand pager as Part A, but the unit that is mapped and
 * filled on one fault is a CHUNK of CHUNK_PAGES contiguous hardware pages,
 * and up to RESIDENT_CHUNKS chunks are kept in memory at once.  When the
 * resident set is full the OLDEST chunk is evicted (FIFO replacement).
 *
 *   -DCHUNK_PAGES=<n>      pages per fault               (default 1)
 *   -DRESIDENT_CHUNKS=<n>  chunks kept resident (FIFO)    (default 1)
 *
 * Course topics used (tags refer to the lecture / tutorial numbers):
 *   [L10, T9]    sigaction/SA_SIGINFO, siginfo_t, async-signal-safe handler
 *   [L18-L20]    virtual memory, pages, VPN/offset arithmetic
 *   [L22]        demand paging; page-replacement policy = FIFO  (FIFO, MIN,
 *                LRU, Clock are compared there); spatial locality: a bigger
 *                "page" helps sequential access (compulsory-miss reduction)
 *                but costs more per miss (miss penalty)
 *   [L22]        EAT-style cost model: cost = hit time + miss rate * penalty
 *   [T10]        mmap(MAP_FIXED|MAP_PRIVATE|MAP_ANONYMOUS), munmap,
 *                getrusage / maxrss measurement, RLIMIT_AS accounting
 *
 * Build, e.g.:
 *   gcc -O2 -Wall -Wextra -DCHUNK_PAGES=16 -DRESIDENT_CHUNKS=4 \
 *       -o partB partB.c -lm
 *
 * Changes w.r.t. the starter are marked "[PA5]".  Output: the starter's
 * messages, then a human readable block and one machine readable
 * "STATS ..." line that scripts/run_bench.py parses.
 */
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <math.h>

/* ---- [PA5] compile-time configuration (Part B requirement) ------------- */
#ifndef CHUNK_PAGES
#define CHUNK_PAGES 1       // pages per fault (1, 2, 4, 8, 16, 64, ...)
#endif

#ifndef RESIDENT_CHUNKS
#define RESIDENT_CHUNKS 1   // chunks kept in memory (FIFO eviction)
#endif

#if CHUNK_PAGES < 1 || RESIDENT_CHUNKS < 1
#error "CHUNK_PAGES and RESIDENT_CHUNKS must both be >= 1"
#endif

static size_t page_size;

// align_down - rounds a value down to an alignment
// @x: the value
// @a: the alignment (must be power of 2)
//
// Returns an aligned value.
#define align_down(x, a) ((x) & ~((typeof(x))(a) - 1))

#define AS_LIMIT	(1 << 23) // Maximum limit on virtual memory bytes
#define MAX_SQRTS	(1 << 27) // Maximum limit on sqrt table entries
static double *sqrts;

// Use this helper function as an oracle for square root values.
static void
calculate_sqrts(double *sqrt_pos, int start, int nr)
{
  int i;

  for (i = 0; i < nr; i++)
    sqrt_pos[i] = sqrt((double)(start + i));
}

/* ------------------------------------------------------------------------
 * [PA5] Pager state.
 *
 * fifo[] is the small FIFO array of chunk base addresses requested by the
 * assignment.  It is used as a circular queue:
 *   - fifo[fifo_next] is always the OLDEST resident chunk (the next victim);
 *     0 means "slot still empty".
 *   - after a new chunk is installed in that slot, fifo_next advances.
 * Only the signal handler touches these variables, and SIGSEGV is blocked
 * while the handler runs, so no locking is needed.
 * ---------------------------------------------------------------------- */
static size_t    chunk_bytes;               /* CHUNK_PAGES * page_size       */
static uintptr_t fifo[RESIDENT_CHUNKS];     /* resident chunk base addresses */
static unsigned  fifo_next;                 /* index of the oldest chunk     */

/* Counters read by main() after the test.  volatile because they are
 * modified from a signal handler (async w.r.t. the main flow). */
static volatile unsigned long nr_faults;          /* total SIGSEGV invocations */
static volatile unsigned long nr_faults_phase[2]; /* [0]=random jumps, [1]=pos+1 */
static volatile sig_atomic_t  cur_phase;          /* set by the test loop     */

/* ------------------------------------------------------------------------
 * Async-signal-safe diagnostics (write + _exit only; see partA.c for why
 * printf must not be used inside a handler).
 * ---------------------------------------------------------------------- */
static void
sig_puts(const char *s)
{
  size_t n = 0;
  while (s[n] != '\0')
    n++;
  ssize_t r = write(STDERR_FILENO, s, n);
  (void)r;                       /* nobody left to tell if this fails */
}

static void
sig_put_num(uintptr_t v, unsigned base)   /* base 10 or 16 */
{
  char buf[2 + 2 * sizeof(uintptr_t) + 1];
  int i = (int)sizeof(buf) - 1;

  buf[i] = '\0';
  do {
    buf[--i] = "0123456789abcdef"[v % base];
    v /= base;
  } while (v != 0);
  if (base == 16) {
    buf[--i] = 'x';
    buf[--i] = '0';
  }
  sig_puts(&buf[i]);
}

/* Print "<msg> (addr 0x.., errno N)\n" and terminate with EXIT_FAILURE.
 * errno is passed in by the caller because the value must be captured
 * right after the failing call. */
static void
sig_die(const char *msg, uintptr_t addr, int err)
{
  sig_puts(msg);
  sig_puts(" (addr ");
  sig_put_num(addr, 16);
  sig_puts(", errno ");
  sig_put_num((uintptr_t)err, 10);
  sig_puts(")\n");
  _exit(EXIT_FAILURE);
}

/* ------------------------------------------------------------------------
 * handle_sigsegv - the "page-fault handler" with chunking + FIFO eviction.
 * ---------------------------------------------------------------------- */
static void
handle_sigsegv(int sig, siginfo_t *si, void *ctx)
{
  (void)sig;
  (void)ctx;
  int saved_errno = errno;              /* restored before returning */

  /* 1. faulting address */
  uintptr_t fault_addr = (uintptr_t)si->si_addr;

  /* 2. must lie inside the table and be a "not mapped" fault, otherwise it
   *    is a genuine bug and we must not paper over it  (see partA.c). */
  uintptr_t table_lo = (uintptr_t)sqrts;
  uintptr_t table_hi = table_lo + (uintptr_t)MAX_SQRTS * sizeof(double);

  if (fault_addr < table_lo || fault_addr >= table_hi ||
      si->si_code != SEGV_MAPERR)
    sig_die("genuine SIGSEGV (outside table / not a missing page)",
            fault_addr, 0);

  nr_faults++;
  nr_faults_phase[cur_phase & 1]++;

  /* 3. round down to the CHUNK boundary.  The chunks tile the table starting
   *    at its (page aligned) base, so the chunk containing the fault is
   *    found with plain integer arithmetic.  (align_down would need a
   *    power-of-two size; this also works for e.g. CHUNK_PAGES=3, which the
   *    "largest configuration" experiment of Part B Q4 needs.) */
  uintptr_t offset = fault_addr - table_lo;
  uintptr_t chunk  = table_lo + (offset - offset % chunk_bytes);

  /* The last chunk is clamped so we never map beyond the table's end. */
  size_t len = chunk_bytes;
  if (chunk + len > table_hi)
    len = (size_t)(table_hi - chunk);

  /* 4. evict the OLDEST resident chunk (FIFO) so we stay under RLIMIT_AS.
   *    Doing the eviction BEFORE the new mmap means at most
   *    RESIDENT_CHUNKS chunks are ever mapped at the same time.
   *    The old chunk may be shorter than chunk_bytes only if it was the
   *    table's last chunk; munmap of a range whose tail is already unmapped
   *    is harmless, so we just unmap chunk_bytes. */
  if (fifo[fifo_next] != 0) {
    if (munmap((void *)fifo[fifo_next], chunk_bytes) == -1)
      sig_die("munmap of evicted chunk failed", fifo[fifo_next], errno);
    fifo[fifo_next] = 0;
  }

  /* 5. map the new chunk at exactly 'chunk' */
  void *p = mmap((void *)chunk, len, PROT_READ | PROT_WRITE,
                 MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (p == MAP_FAILED || (uintptr_t)p != chunk)
    sig_die("mmap of new chunk failed", chunk, errno);

  /* 6. install it in the FIFO and advance the queue pointer */
  fifo[fifo_next] = chunk;
  fifo_next = (fifo_next + 1) % RESIDENT_CHUNKS;

  /* 7. fill the whole chunk: first table index on the chunk, then every
   *    double that fits in 'len' bytes. */
  int start = (int)((chunk - table_lo) / sizeof(double));
  int nr    = (int)(len / sizeof(double));
  calculate_sqrts((double *)chunk, start, nr);

  errno = saved_errno;   /* 8. return -> faulting instruction is retried */
}

static void
setup_sqrt_region(void)
{
  struct rlimit lim = {AS_LIMIT, AS_LIMIT};
  struct sigaction act;

  // Only mapping to find a safe location for the table.
  sqrts = mmap(NULL, MAX_SQRTS * sizeof(double) + AS_LIMIT, PROT_NONE,
	       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sqrts == MAP_FAILED) {
    fprintf(stderr, "Couldn't mmap() region for sqrt table; %s\n",
	    strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Now release the virtual memory to remain under the rlimit.
  if (munmap(sqrts, MAX_SQRTS * sizeof(double) + AS_LIMIT) == -1) {
    fprintf(stderr, "Couldn't munmap() region for sqrt table; %s\n",
            strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Set a soft rlimit on virtual address-space bytes.
  if (setrlimit(RLIMIT_AS, &lim) == -1) {
    fprintf(stderr, "Couldn't set rlimit on RLIMIT_AS; %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Register a signal handler to capture SIGSEGV.
  act.sa_sigaction = handle_sigsegv;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

static void
test_sqrt_region(void)
{
  int i, pos = rand() % (MAX_SQRTS - 1);
  double correct_sqrt;

  printf("Validating square root table contents...\n");
  srand(0xDEADBEEF);

  for (i = 0; i < 500000; i++) {
    cur_phase = i & 1;            /* [PA5] bookkeeping only: 0 = random half,
                                   *       1 = "pos + 1" (sequential) half */
    if (i % 2 == 0)
      pos = rand() % (MAX_SQRTS - 1);
    else
      pos += 1;
    calculate_sqrts(&correct_sqrt, pos, 1);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }

  printf("All tests passed!\n");
}

/* [PA5] Peak resident set size of THIS process in KiB, read from
 * /proc/self/status (VmHWM = "high water mark" of the current address space).
 * Why not only ru_maxrss?  Linux keeps ru_maxrss across fork()+exec(): a
 * child started from a large parent (e.g. our benchmark driver, ~15 MB)
 * reports the PARENT's peak, hiding the pager's tiny footprint.  VmHWM is
 * reset by exec, so it measures just this program.  Returns -1 on error.
 * (Only called from main(), never from the signal handler.) */
static long
read_vmhwm_kib(void)
{
  FILE *f = fopen("/proc/self/status", "r");
  char line[256];
  long kib = -1;

  if (f == NULL)
    return -1;
  while (fgets(line, sizeof(line), f) != NULL)
    if (sscanf(line, "VmHWM: %ld kB", &kib) == 1)
      break;
  fclose(f);
  return kib;
}

int
main(int argc, char *argv[])
{
  (void)argc;
  (void)argv;
  page_size = sysconf(_SC_PAGESIZE);
  chunk_bytes = (size_t)CHUNK_PAGES * page_size;       /* [PA5] */
  printf("page_size is %ld\n", page_size);

  /* [PA5] Sanity check on the configured footprint.  The limit also has to
   * cover the program image, libc/libm and the stack, so warn if the pager
   * alone would use more than the whole limit.  We still run (do not exit)
   * so that Part B Q4 can observe how an oversized configuration fails. */
  size_t footprint = chunk_bytes * RESIDENT_CHUNKS;
  printf("config: CHUNK_PAGES=%d RESIDENT_CHUNKS=%d -> %zu KiB resident max\n",
         CHUNK_PAGES, RESIDENT_CHUNKS, footprint / 1024);
  if (footprint >= AS_LIMIT)
    fprintf(stderr, "warning: footprint >= AS_LIMIT, expect mmap ENOMEM\n");

  setup_sqrt_region();

  /* [PA5] wall time around the validation test only (monotonic clock). */
  struct timespec t0, t1;
  clock_gettime(CLOCK_MONOTONIC, &t0);
  test_sqrt_region();
  clock_gettime(CLOCK_MONOTONIC, &t1);
  double wall = (double)(t1.tv_sec - t0.tv_sec) +
                (double)(t1.tv_nsec - t0.tv_nsec) / 1e9;

  struct rusage ru;
  if (getrusage(RUSAGE_SELF, &ru) == -1) {
    perror("getrusage");
    return EXIT_FAILURE;
  }
  printf("minor faults: %ld, major faults: %ld, maxrss: %ld KiB\n",
         ru.ru_minflt, ru.ru_majflt, ru.ru_maxrss);
  printf("SIGSEGV handler invocations: %lu (random half %lu, sequential half %lu)\n",
         nr_faults, nr_faults_phase[0], nr_faults_phase[1]);
  long hwm = read_vmhwm_kib();
  printf("peak RSS (VmHWM): %ld KiB\n", hwm);
  printf("wall time: %.3f s\n", wall);
  printf("STATS chunk_pages=%d resident_chunks=%d sigsegv=%lu sigsegv_rand=%lu "
         "sigsegv_seq=%lu minflt=%ld majflt=%ld maxrss_kib=%ld vmhwm_kib=%ld wall_s=%.4f\n",
         CHUNK_PAGES, RESIDENT_CHUNKS, nr_faults, nr_faults_phase[0],
         nr_faults_phase[1], ru.ru_minflt, ru.ru_majflt, ru.ru_maxrss, hwm, wall);
  return 0;
}
