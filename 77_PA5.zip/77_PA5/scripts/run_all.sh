#!/bin/bash
# Regenerates every number used in the report (about 25 minutes).  One
# benchmark at a time, otherwise the timings are distorted.  Needs `make` first.
cd "$(dirname "$0")/.." || exit 1
mkdir -p results
B="-DCHUNK_PAGES=4 -DRESIDENT_CHUNKS=4"
scripts/run_bench.sh partB.c 5 \
  "1x1|-DCHUNK_PAGES=1 -DRESIDENT_CHUNKS=1"   "4x1|-DCHUNK_PAGES=4 -DRESIDENT_CHUNKS=1" \
  "16x1|-DCHUNK_PAGES=16 -DRESIDENT_CHUNKS=1" "64x1|-DCHUNK_PAGES=64 -DRESIDENT_CHUNKS=1" \
  "1x16|-DCHUNK_PAGES=1 -DRESIDENT_CHUNKS=16" "16x4|-DCHUNK_PAGES=16 -DRESIDENT_CHUNKS=4" | tee results/B.log
scripts/find_limit.sh | tee results/B_limit.log
scripts/run_bench.sh partC.c 5 "baseline|$B" "C1 DONTNEED|$B -DC1_DONTNEED" \
  "C2 SEQUENTIAL|$B -DC2_SEQUENTIAL" "C2 RANDOM|$B -DC2_RANDOM" \
  "C3 prefetch|$B -DC3_PREFETCH" "C3 prefetch+WILLNEED|$B -DC3_WILLNEED" | tee results/C.log
scripts/run_bench.sh partC.c 5 "seq baseline|$B -DSEQ_TEST" "seq prefetch|$B -DSEQ_TEST -DC3_PREFETCH" \
  "seq prefetch+WILLNEED|$B -DSEQ_TEST -DC3_WILLNEED" | tee results/C_seq.log
./demoC1 | tee results/C1_demo.log
scripts/run_bonus.sh 3 bonus  | tee results/bonus.log
scripts/run_bonus.sh 5 bonusS | tee results/bonusS.log
