#!/bin/bash
# Part B, Q4: largest resident footprint (pages) that still passes under the
# 8 MiB RLIMIT_AS.  Bisects RESIDENT_CHUNKS with CHUNK_PAGES=1.
cd "$(dirname "$0")/.." || exit 1
passes() {   # passes N -> 0 if the program with N resident pages passes
  gcc -O2 -DCHUNK_PAGES=1 -DRESIDENT_CHUNKS=$1 -o /tmp/limit_$$ partB.c -lm || exit 1
  /tmp/limit_$$ 2>/dev/null | grep -q "All tests passed!"
}
lo=1; hi=2048                       # 2048 pages = 8 MiB: certainly too big
while [ $((hi - lo)) -gt 1 ]; do
  mid=$(((lo + hi) / 2))
  if passes $mid; then lo=$mid; else hi=$mid; fi
done
echo "largest passing footprint : $lo pages = $((lo * 4)) KiB (CHUNK_PAGES=1, RESIDENT_CHUNKS=$lo)"
echo "smallest failing footprint: $hi pages = $((hi * 4)) KiB"
echo "=> baseline VmSize ~ $((8192 - lo * 4)) KiB (+/- 4 KiB)"
passes $hi; /tmp/limit_$$ >/dev/null 2>/tmp/limit_err_$$; echo "failing run: exit status $?"
echo "  stderr: $(cat /tmp/limit_err_$$)"
rm -f /tmp/limit_$$ /tmp/limit_err_$$
