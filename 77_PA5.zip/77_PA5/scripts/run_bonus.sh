#!/bin/bash
# Bonus: cold vs warm page cache for the four hint variants.
# usage: scripts/run_bonus.sh <reps> [bonus|bonusS]     (needs a prior `make`)
#   bonus  = starter access pattern, bonusS = one sequential pass over the file
# Cold = page cache dropped first (root: drop_caches; otherwise
# `./bonus --drop` = posix_fadvise(DONTNEED)); warm = run again right after.
cd "$(dirname "$0")/.." || exit 1
. scripts/lib.sh
reps=${1:-3}; pre=${2:-bonus}
./bonus --create || exit 1
drop() { sync; if ! echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; then ./bonus --drop; fi; }
for v in "" _seq _rand _will; do
  exe=./$pre$v; tc=$(mktemp -d)
  for i in $(seq "$reps"); do
    drop; $exe --run | grep '^STATS ' > "$tc/c$i"
    $exe --run | grep '^STATS ' > "$tc/w$i"
  done
  for st in c w; do
    printf '%-14s %s ' "$pre$v" "$([ $st = c ] && echo cold || echo warm)"
    for k in sigsegv minflt majflt wall_s; do
      printf '%s=%s ' $k "$(for i in $(seq "$reps"); do stat_of $k < "$tc/$st$i"; done | median)"
    done; echo
  done
  rm -rf "$tc"
done
