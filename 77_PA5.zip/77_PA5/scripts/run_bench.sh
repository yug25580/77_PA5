#!/bin/bash
# usage: scripts/run_bench.sh <source.c> <repeats> "label|-Dflags" ...
# Builds each configuration, runs it <repeats> times as fresh processes and
# prints the MEDIAN of sigsegv / minflt / majflt / VmHWM / wall time.
# Example: scripts/run_bench.sh partB.c 5 "4x1|-DCHUNK_PAGES=4 -DRESIDENT_CHUNKS=1"
cd "$(dirname "$0")/.." || exit 1
. scripts/lib.sh
src=$1; reps=$2; shift 2
for spec in "$@"; do
  label=${spec%%|*}; flags=${spec#*|}
  exe=/tmp/bench_$$
  gcc -O2 -Wall -Wextra $flags -o $exe "$src" -lm || exit 1
  printf '%-24s' "$label"; bench_exe $exe "$reps"
done
rm -f /tmp/bench_$$
