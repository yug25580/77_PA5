#!/bin/bash
# Shared helpers for the benchmark scripts (plain bash + coreutils only).

# median of the numbers given on stdin (one per line)
median() { sort -g | awk '{a[NR]=$1} END{print (NR%2)?a[(NR+1)/2]:(a[NR/2]+a[NR/2+1])/2}'; }

# stat KEY < "STATS k=v k=v ..." line  ->  value of KEY
stat_of() { sed -n 's/^STATS .*[[:space:]]'"$1"'=\([^[:space:]]*\).*/\1/p; s/^STATS '"$1"'=\([^[:space:]]*\).*/\1/p' | tail -1; }

# run EXE N : run a built program N times (fresh process each time), require
# "All tests passed!", print median of the main metrics on one line.
bench_exe() {
  local exe=$1 n=$2 i out
  local tmp; tmp=$(mktemp -d)
  for i in $(seq "$n"); do
    out=$("$exe") || { echo "FAILED: $exe exited non-zero"; return 1; }
    grep -q "All tests passed!" <<<"$out" || { echo "FAILED: $exe did not pass"; return 1; }
    grep '^STATS ' <<<"$out" | tail -1 > "$tmp/$i"
  done
  local line="" k
  for k in sigsegv sigsegv_rand sigsegv_seq minflt majflt vmhwm_kib wall_s; do
    line="$line $k=$(for i in $(seq "$n"); do stat_of $k < "$tmp/$i"; done | median)"
  done
  rm -rf "$tmp"
  echo "$line"
}
