/*
 * demoC1_dontneed_only.c  --  supporting demo for Part C1 (design question).
 *
 * Question C1 asks: "describe a design where MADV_DONTNEED would be the ONLY
 * eviction step ... Why does that design conflict with RLIMIT_AS for a 1 GiB
 * table?"  This small program shows the three facts the answer rests on:
 *
 *   (1) MADV_DONTNEED frees the PHYSICAL pages (VmRSS drops) but keeps the
 *       VIRTUAL mapping (VmSize unchanged); munmap() drops both.
 *   (2) After MADV_DONTNEED, a private anonymous page reads back as zeros and
 *       raises NO fault -> a SIGSEGV-driven pager would never be told that
 *       the chunk needs refilling.  (You would additionally have to
 *       mprotect(PROT_NONE) the dropped chunk to get a fault again.)
 *   (3) RLIMIT_AS limits VmSize, not VmRSS, so keeping the whole 1 GiB table
 *       mapped (the "DONTNEED-only" design) fails with ENOMEM under 8 MiB.
 *
 * Course topics used:  [T10] mmap/madvise/munmap + MADV_DONTNEED semantics,
 * /proc/PID/status; [L18-L20] virtual vs physical memory, zero-fill on
 * demand; [L18] RLIMIT_AS accounts virtual address space.
 *
 * Build: gcc -O2 -Wall -Wextra -o demoC1 demoC1_dontneed_only.c
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/resource.h>

/* read one "<key>: <n> kB" line from /proc/self/status */
static long
status_kib(const char *key)
{
  FILE *f = fopen("/proc/self/status", "r");
  char line[256];
  long v = -1;
  size_t klen = strlen(key);

  if (f == NULL)
    return -1;
  while (fgets(line, sizeof(line), f) != NULL)
    if (strncmp(line, key, klen) == 0 && line[klen] == ':') {
      sscanf(line + klen + 1, "%ld", &v);
      break;
    }
  fclose(f);
  return v;
}

static void
show(const char *when)
{
  printf("  %-34s VmSize=%6ld KiB   VmRSS=%6ld KiB\n", when,
         status_kib("VmSize"), status_kib("VmRSS"));
}

int
main(void)
{
  const size_t len = 2u << 20;               /* 2 MiB demo region */
  size_t i;

  /* same limit as the assignment: 8 MiB of virtual address space */
  struct rlimit lim = {8u << 20, 8u << 20};
  if (setrlimit(RLIMIT_AS, &lim) == -1) {
    perror("setrlimit");
    return EXIT_FAILURE;
  }

  printf("(1) MADV_DONTNEED vs munmap on a private anonymous region\n");
  show("before mmap");
  unsigned char *r = mmap(NULL, len, PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (r == MAP_FAILED) {
    perror("mmap 2 MiB");
    return EXIT_FAILURE;
  }
  show("after mmap (nothing touched yet)");

  for (i = 0; i < len; i += 4096)            /* touch every page: allocate */
    r[i] = 0xAB;
  show("after touching every page");

  if (madvise(r, len, MADV_DONTNEED) == -1) {
    perror("madvise");
    return EXIT_FAILURE;
  }
  show("after MADV_DONTNEED");

  printf("\n(2) contents after MADV_DONTNEED: r[0]=0x%02x r[4096]=0x%02x "
         "(zero-filled, and NO SIGSEGV was raised)\n", r[0], r[4096]);

  if (munmap(r, len) == -1) {
    perror("munmap");
    return EXIT_FAILURE;
  }
  show("after munmap");

  printf("\n(3) the 'DONTNEED is the only eviction step' design needs the whole\n"
         "    1 GiB table mapped read/write at once under RLIMIT_AS = 8 MiB:\n");
  void *whole = mmap(NULL, (size_t)1 << 30, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (whole == MAP_FAILED)
    printf("    mmap(1 GiB) failed: %s (errno %d)  -> conflicts with RLIMIT_AS\n",
           strerror(errno), errno);
  else {
    printf("    mmap(1 GiB) unexpectedly succeeded\n");
    munmap(whole, (size_t)1 << 30);
  }
  return 0;
}
