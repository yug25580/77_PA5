/*
 * bonus.c  --  CSE231 PA-5 Bonus: turn minor faults into MAJOR faults.
 *
 * The pager of Parts A-C produced zero-filled ANONYMOUS pages, so every
 * fault was a minor fault (no disk I/O).  Here the table is backed by a
 * FILE (sqrts.bin, a 64 MiB slice = the first 2^23 entries of the table).
 * On a SIGSEGV the handler maps the faulting chunk from the file:
 *
 *      mmap(chunk_addr, chunk_bytes, PROT_READ,
 *           MAP_PRIVATE | MAP_FIXED, fd, file_offset);
 *
 * The values now come from the file, so the handler no longer calls
 * calculate_sqrts().  When the program then touches the freshly mapped
 * chunk, the kernel takes a second, ordinary page fault:
 *     - page already in the page cache  -> MINOR fault (just map it)
 *     - page NOT in the page cache      -> MAJOR fault (disk read)
 * ru_majflt counts the latter.
 *
 * Course topics used (tags = lecture / tutorial numbers):
 *   [T10]      file-backed mmap, MAP_PRIVATE vs MAP_SHARED, PROT_READ,
 *              madvise (SEQUENTIAL / RANDOM / WILLNEED), getrusage
 *   [L20,L22]  demand paging from disk: page fault -> "load page from disk"
 *              -> update PTE -> retry; the page cache plays the role of
 *              main memory acting as a cache for the disk; EAT with a
 *              page-fault penalty (ms vs ns); locality / read-ahead
 *   [L10,T9]   sigaction, async-signal-safe handler (write/_exit only)
 *   [L8-9]     open/write/close, fd inherited by the handler as a global
 *
 * Variants (compile-time):
 *   -DCHUNK_PAGES=n -DRESIDENT_CHUNKS=n   as in Part B   (defaults 4 and 4)
 *   -DB_SEQUENTIAL   madvise(chunk, len, MADV_SEQUENTIAL) on each mapped chunk
 *   -DB_RANDOM       madvise(chunk, len, MADV_RANDOM)     on each mapped chunk
 *   -DB_WILLNEED     also map the NEXT chunk and madvise(next, len,
 *                    MADV_WILLNEED) (needs RESIDENT_CHUNKS >= 2; madvise
 *                    requires a mapped range, hence the extra mmap)
 *
 * Usage:  ./bonus            create sqrts.bin if missing, then run the test
 *         ./bonus --create   (re)create sqrts.bin and exit
 *         ./bonus --drop     evict sqrts.bin from the page cache (no root
 *                            needed) and exit -- fallback for drop_caches
 *         ./bonus --run      run the test only (file must exist)
 *
 * The test accesses only the 2^23-entry slice that the file contains
 * (positions are taken modulo the slice length); anything else in the table
 * would be a genuine bug and is reported.
 *
 * Build: gcc -O2 -Wall -Wextra -o bonus bonus.c -lm
 */
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <math.h>

#ifndef CHUNK_PAGES
#define CHUNK_PAGES 4
#endif
#ifndef RESIDENT_CHUNKS
#define RESIDENT_CHUNKS 4
#endif
#if defined(B_WILLNEED) && RESIDENT_CHUNKS < 2
#error "B_WILLNEED maps the next chunk too: needs RESIDENT_CHUNKS >= 2"
#endif

#define BACKING_FILE   "sqrts.bin"
#define AS_LIMIT       (1 << 23)                 /* 8 MiB virtual memory      */
#define MAX_SQRTS      (1 << 27)                 /* full table (1 GiB)        */
#define SLICE_ENTRIES  (1 << 23)                 /* entries stored in the file */
#define SLICE_BYTES    ((size_t)SLICE_ENTRIES * sizeof(double))   /* 64 MiB  */

static size_t page_size;
static double *sqrts;
static int     backing_fd = -1;                  /* sqrts.bin, read-only      */

static size_t    chunk_bytes;
static uintptr_t fifo[RESIDENT_CHUNKS];          /* resident chunk bases      */
static unsigned  fifo_next;                      /* oldest = next victim      */
static uintptr_t table_lo, slice_hi;             /* file-backed range [lo,hi) */

static volatile unsigned long nr_faults;
static volatile unsigned long nr_faults_phase[2];
static volatile sig_atomic_t  cur_phase;

/* ---- async-signal-safe diagnostics (write + _exit only) ----------------- */
static void
sig_puts(const char *s)
{
  size_t n = 0;
  while (s[n] != '\0')
    n++;
  ssize_t r = write(STDERR_FILENO, s, n);
  (void)r;
}

static void
sig_put_num(uintptr_t v, unsigned base)
{
  char buf[2 + 2 * sizeof(uintptr_t) + 1];
  int i = (int)sizeof(buf) - 1;

  buf[i] = '\0';
  do {
    buf[--i] = "0123456789abcdef"[v % base];
    v /= base;
  } while (v != 0);
  if (base == 16) {
    buf[--i] = 'x';
    buf[--i] = '0';
  }
  sig_puts(&buf[i]);
}

static void
sig_die(const char *msg, uintptr_t addr, int err)
{
  sig_puts(msg);
  sig_puts(" (addr ");
  sig_put_num(addr, 16);
  sig_puts(", errno ");
  sig_put_num((uintptr_t)err, 10);
  sig_puts(")\n");
  _exit(EXIT_FAILURE);
}

#ifdef B_WILLNEED
static int
is_resident(uintptr_t chunk)
{
  for (unsigned i = 0; i < RESIDENT_CHUNKS; i++)
    if (fifo[i] == chunk)
      return 1;
  return 0;
}
#endif

/* ------------------------------------------------------------------------
 * install_chunk - evict the oldest chunk (FIFO) and map 'chunk' from the file.
 *   file offset of a chunk == its offset from the table base, because the
 *   file holds table entries 0 .. SLICE_ENTRIES-1 in order.  Offsets are
 *   multiples of page_size (chunks tile the page-aligned table), which is
 *   what mmap() requires of the file offset.
 * ---------------------------------------------------------------------- */
static void
install_chunk(uintptr_t chunk)
{
  size_t len = chunk_bytes;
  if (chunk + len > slice_hi)                    /* never map past EOF: that
                                                    would raise SIGBUS later */
    len = (size_t)(slice_hi - chunk);

  uintptr_t victim = fifo[fifo_next];
  if (victim != 0) {
    if (munmap((void *)victim, chunk_bytes) == -1)
      sig_die("munmap of evicted chunk failed", victim, errno);
    fifo[fifo_next] = 0;
  }

  /* PROT_READ + MAP_PRIVATE: the table is only read, so the kernel never
   * has to write anything back; a private mapping never propagates writes
   * to the file anyway (copy-on-write). */
  void *p = mmap((void *)chunk, len, PROT_READ, MAP_PRIVATE | MAP_FIXED,
                 backing_fd, (off_t)(chunk - table_lo));
  if (p == MAP_FAILED || (uintptr_t)p != chunk)
    sig_die("mmap of file chunk failed", chunk, errno);

#if defined(B_SEQUENTIAL)
  if (madvise((void *)chunk, len, MADV_SEQUENTIAL) == -1)
    sig_die("madvise(MADV_SEQUENTIAL) failed", chunk, errno);
#elif defined(B_RANDOM)
  if (madvise((void *)chunk, len, MADV_RANDOM) == -1)
    sig_die("madvise(MADV_RANDOM) failed", chunk, errno);
#endif

  fifo[fifo_next] = chunk;
  fifo_next = (fifo_next + 1) % RESIDENT_CHUNKS;
}

static void
handle_sigsegv(int sig, siginfo_t *si, void *ctx)
{
  (void)sig;
  (void)ctx;
  int saved_errno = errno;

  uintptr_t fault_addr = (uintptr_t)si->si_addr;
  /* valid faults: not-mapped addresses inside the FILE-BACKED slice only.
   * A write to a PROT_READ chunk would be SEGV_ACCERR -> genuine bug. */
  if (fault_addr < table_lo || fault_addr >= slice_hi ||
      si->si_code != SEGV_MAPERR)
    sig_die("genuine SIGSEGV (outside the file-backed slice)", fault_addr, 0);

  nr_faults++;
  nr_faults_phase[cur_phase & 1]++;

  uintptr_t offset = fault_addr - table_lo;
  uintptr_t chunk  = table_lo + (offset - offset % chunk_bytes);
  install_chunk(chunk);

#ifdef B_WILLNEED
  /* Map the following chunk too and ask the kernel to read its file pages
   * into the page cache NOW (asynchronous read-ahead): if the access
   * pattern is sequential the next touch is then a cheap minor fault
   * instead of a disk read.  madvise() only works on mapped ranges, which is
   * why the chunk has to be mapped first. */
  uintptr_t next = chunk + chunk_bytes;
  if (next < slice_hi && !is_resident(next)) {
    install_chunk(next);
    size_t nlen = chunk_bytes;
    if (next + nlen > slice_hi)
      nlen = (size_t)(slice_hi - next);
    if (madvise((void *)next, nlen, MADV_WILLNEED) == -1)
      sig_die("madvise(MADV_WILLNEED) failed", next, errno);
  }
#endif
  errno = saved_errno;
}

/* ------------------------------------------------------------------------
 * Backing-file management (runs in normal context, before RLIMIT_AS is set)
 * ---------------------------------------------------------------------- */

/* write() may transfer fewer bytes than asked [HW3: short writes]: loop. */
static int
write_all(int fd, const void *buf, size_t n)
{
  const char *p = buf;
  while (n > 0) {
    ssize_t w = write(fd, p, n);
    if (w == -1) {
      if (errno == EINTR)
        continue;
      return -1;
    }
    p += w;
    n -= (size_t)w;
  }
  return 0;
}

/* Create sqrts.bin: SLICE_ENTRIES doubles, entry i = sqrt(i). */
static int
create_backing_file(void)
{
  int fd = open(BACKING_FILE, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd == -1) {
    perror("open(" BACKING_FILE ")");
    return -1;
  }

  enum { BATCH = 1 << 13 };                      /* 8192 doubles = 64 KiB */
  static double buf[BATCH];
  for (long i = 0; i < SLICE_ENTRIES; i += BATCH) {
    for (int j = 0; j < BATCH; j++)
      buf[j] = sqrt((double)(i + j));
    if (write_all(fd, buf, sizeof(buf)) == -1) {
      perror("write(" BACKING_FILE ")");
      close(fd);
      return -1;
    }
  }
  /* make the data durable, so that dropping the page cache afterwards
   * really leaves nothing but the on-disk copy */
  if (fsync(fd) == -1 || close(fd) == -1) {
    perror("fsync/close(" BACKING_FILE ")");
    return -1;
  }
  return 0;
}

/* Is there a complete backing file already? */
static int
backing_file_ok(void)
{
  struct stat st;
  return stat(BACKING_FILE, &st) == 0 && (size_t)st.st_size == SLICE_BYTES;
}

/* Evict the file's clean pages from the page cache without needing root
 * (alternative to  sync; echo 3 > /proc/sys/vm/drop_caches). */
static int
drop_file_cache(void)
{
  int fd = open(BACKING_FILE, O_RDONLY);
  if (fd == -1) {
    perror("open(" BACKING_FILE ")");
    return -1;
  }
  if (fsync(fd) == -1)                           /* only clean pages can go */
    perror("fsync");
  int rc = posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);
  if (rc != 0)
    fprintf(stderr, "posix_fadvise: %s\n", strerror(rc));
  close(fd);
  return rc == 0 ? 0 : -1;
}

static void
setup_sqrt_region(void)
{
  struct rlimit lim = {AS_LIMIT, AS_LIMIT};
  struct sigaction act;

  /* reserve 1 GiB of addresses exactly like the starter, then release them */
  sqrts = mmap(NULL, MAX_SQRTS * sizeof(double) + AS_LIMIT, PROT_NONE,
               MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sqrts == MAP_FAILED) {
    fprintf(stderr, "Couldn't mmap() region for sqrt table; %s\n",
            strerror(errno));
    exit(EXIT_FAILURE);
  }
  if (munmap(sqrts, MAX_SQRTS * sizeof(double) + AS_LIMIT) == -1) {
    fprintf(stderr, "Couldn't munmap() region for sqrt table; %s\n",
            strerror(errno));
    exit(EXIT_FAILURE);
  }
  if (setrlimit(RLIMIT_AS, &lim) == -1) {
    fprintf(stderr, "Couldn't set rlimit on RLIMIT_AS; %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  table_lo = (uintptr_t)sqrts;
  slice_hi = table_lo + SLICE_BYTES;

  act.sa_sigaction = handle_sigsegv;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

/* Same access pattern as the starter test, restricted to the slice that the
 * file holds.  Expected values still come from the oracle sqrt(). */
static void
test_sqrt_region(void)
{
  int i, pos = rand() % (SLICE_ENTRIES - 1);
  double correct_sqrt = 0;

  printf("Validating square root table contents...\n");
#ifdef SEQ_TEST
  /* Extra experiment (-DSEQ_TEST): ONE purely sequential pass over the whole
   * 64 MiB slice.  The starter pattern touches only a single neighbour of
   * each random position, so it can hardly show what MADV_SEQUENTIAL or
   * MADV_WILLNEED do for a real sequential scan; this walk can. */
  (void)i; (void)pos; (void)correct_sqrt;
  for (long p = 0; p < SLICE_ENTRIES; p++) {
    cur_phase = 1;
    if (sqrts[p] != sqrt((double)p)) {
      fprintf(stderr, "Square root is incorrect at %ld.\n", p);
      exit(EXIT_FAILURE);
    }
  }
  printf("All tests passed!\n");
  return;
#endif
  srand(0xDEADBEEF);

  for (i = 0; i < 500000; i++) {
    cur_phase = i & 1;
    if (i % 2 == 0)
      pos = rand() % (SLICE_ENTRIES - 1);
    else
      pos += 1;
    correct_sqrt = sqrt((double)pos);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }

  printf("All tests passed!\n");
}

static long
read_vmhwm_kib(void)                             /* see partB.c for why */
{
  FILE *f = fopen("/proc/self/status", "r");
  char line[256];
  long kib = -1;

  if (f == NULL)
    return -1;
  while (fgets(line, sizeof(line), f) != NULL)
    if (sscanf(line, "VmHWM: %ld kB", &kib) == 1)
      break;
  fclose(f);
  return kib;
}

int
main(int argc, char *argv[])
{
  const char *mode = argc > 1 ? argv[1] : "";

  if (strcmp(mode, "--create") == 0)
    return create_backing_file() == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
  if (strcmp(mode, "--drop") == 0)
    return drop_file_cache() == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
  if (strcmp(mode, "--run") != 0 && !backing_file_ok() &&
      create_backing_file() == -1)
    return EXIT_FAILURE;

  page_size = sysconf(_SC_PAGESIZE);
  chunk_bytes = (size_t)CHUNK_PAGES * page_size;
  printf("page_size is %ld\n", page_size);

  const char *variant = "default (no madvise)";
#if defined(B_WILLNEED)
  variant = "MADV_WILLNEED on next chunk";
#elif defined(B_SEQUENTIAL)
  variant = "MADV_SEQUENTIAL";
#elif defined(B_RANDOM)
  variant = "MADV_RANDOM";
#endif
  printf("config: CHUNK_PAGES=%d RESIDENT_CHUNKS=%d variant=%s\n",
         CHUNK_PAGES, RESIDENT_CHUNKS, variant);

  /* open the file BEFORE the rlimit is applied; keep the fd for the handler
   * (it must not call open() itself: open is allowed, but a global fd keeps
   * the handler minimal). */
  backing_fd = open(BACKING_FILE, O_RDONLY);
  if (backing_fd == -1) {
    perror("open(" BACKING_FILE ")");
    return EXIT_FAILURE;
  }
  setup_sqrt_region();

  struct timespec t0, t1;
  clock_gettime(CLOCK_MONOTONIC, &t0);
  test_sqrt_region();
  clock_gettime(CLOCK_MONOTONIC, &t1);
  double wall = (double)(t1.tv_sec - t0.tv_sec) +
                (double)(t1.tv_nsec - t0.tv_nsec) / 1e9;

  struct rusage ru;
  if (getrusage(RUSAGE_SELF, &ru) == -1) {
    perror("getrusage");
    return EXIT_FAILURE;
  }
  long hwm = read_vmhwm_kib();
  printf("minor faults: %ld, major faults: %ld, maxrss: %ld KiB\n",
         ru.ru_minflt, ru.ru_majflt, ru.ru_maxrss);
  printf("SIGSEGV handler invocations: %lu (random half %lu, sequential half %lu)\n",
         nr_faults, nr_faults_phase[0], nr_faults_phase[1]);
  printf("peak RSS (VmHWM): %ld KiB\n", hwm);
  printf("wall time: %.3f s\n", wall);
  printf("STATS chunk_pages=%d resident_chunks=%d sigsegv=%lu sigsegv_rand=%lu "
         "sigsegv_seq=%lu minflt=%ld majflt=%ld maxrss_kib=%ld vmhwm_kib=%ld "
         "wall_s=%.4f\n",
         CHUNK_PAGES, RESIDENT_CHUNKS, nr_faults, nr_faults_phase[0],
         nr_faults_phase[1], ru.ru_minflt, ru.ru_majflt, ru.ru_maxrss, hwm, wall);
  close(backing_fd);
  return 0;
}
