Student 1:

Name: Yug Bhatia
Roll No: 2025580

Name: Shivansh Mujoo
Roll No: 2025476

GitHub link: https://github.com/yug25580/77_PA5

AI USAGE:

Gemini chat link: https://share.gemini.google/RcWA7WAIoCtX

Commands to run the file:

$ make
$ make test

$./partA
$./partB
$./partC

To try other sizes:

$ for cfg in "1 1" "4 1" "16 1" "64 1" "1 16" "16 4"; do set -- $cfg
  gcc -O2 -DCHUNK_PAGES=$1 -DRESIDENT_CHUNKS=$2 -o /tmp/pb partB.c -lm && /tmp/pb | grep -E "^SIGSEGV|^wall"; done

for MiB limit (Q4):

$ scripts/find_limit.sh

Part C:

$ ./partC0     # baseline: SIGSEGV 250096 (249985 / 111), ~1.0M minor faults, ~4 s
$ ./partC1     # MADV_DONTNEED: same counts, slightly slower
$ ./partC2s    # MADV_SEQUENTIAL: same counts
$ ./partC2r    # MADV_RANDOM: same counts
$ ./partC3     # prefetch: SIGSEGV 249985 (random half 249985, sequential half 0)
             #   chunks filled 499968, ~2.0M minor faults, ~7 s
$ ./partC3w    # prefetch + WILLNEED: same counts as partC3
$ ./partC3seq  # pure sequential scan with prefetch: SIGSEGV 1024, chunks filled 2048
$ ./demoC1

Bonus: 

$ ./bonus --create && ls -l sqrts.bin           # exactly 67108864 bytes
$ sync; echo 3 | sudo tee /proc/sys/vm/drop_caches   # cold cache (no root: ./bonus --drop)
$ ./bonus --run      # cold: major faults in the hundreds (about 700)
$ ./bonus --run      # warm: major faults: 0

To compare all four lists over several cold and warm runs:

$ scripts/run_bonus.sh 3 bonus     # starter access pattern
$ scripts/run_bonus.sh 5 bonusS    # one sequential pass over the file